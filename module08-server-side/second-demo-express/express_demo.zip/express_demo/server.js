//Node.js is the engine 
//Express: the framework that runs using Node.js, makes the control of different routes , requests and responses easier

const express= require("express");
const app=express();
const port=8080;

app.get("/", function(request, response){
    console.log("URL: "+request.url);
    response.send(`<h1>Home Page</h1>
        <p>Welcome to our Express Home page</p>`);
});
app.get("/about", function(request, response){
   console.log("URL: "+request.url);
     response.send(`<h1>About Page</h1>
        <p>This page is handeled by Express!</p>`);
});
app.get("/contact", function(request, response){
    response.send("Contact us at haly2@uh.edu");
});

app.get("/students/:studentName/courses/:courseName", function(request, response){
    const studentName=request.params.studentName;
    const courseName=request.params.courseName;

    response.send(`<h1>Student Page</h1>
        <p>Welcome, ${studentName}! Your are enrolled in ${courseName} </p>`);
});
app.use(function(request, response){
    response.status(404).send(`<h1>404 - Page Not found!</h1>`);

});
app.listen(port, function(){
    console.log("Server running at port : "+port);
})